'use strict';

console.log('\'Allo \'Allo!');

function initMap() {
	console.log("Batata")

	$.post({url: "http://www.urbs.curitiba.pr.gov.br/PORTAL/itinerarios/ext/getCarros.php",
		data: {linha: 616},
		dataType: 'jsonp',
		success: function(data) {
			console.log(data);
		},
		error: function(data) {
			console.log(data);
		}
	})
  var directionsService = new google.maps.DirectionsService;
  var directionsDisplay = new google.maps.DirectionsRenderer;
  var map = new google.maps.Map(document.getElementById('map'), {
    zoom: 15,
    center: {lat: -25.412916, lng: -49.267349}
  });
  directionsDisplay.setMap(map);
  directionsDisplay.setPanel(document.getElementById('right-panel'));

  var onChangeHandler = function() {
    calculateAndDisplayRoute(directionsService, directionsDisplay);
  };
  document.getElementById('start').addEventListener('change', onChangeHandler);
  document.getElementById('end').addEventListener('change', onChangeHandler);
}

function calculateAndDisplayRoute(directionsService, directionsDisplay) {
  directionsService.route({
    origin: document.getElementById('start').value,
    destination: document.getElementById('end').value,
    travelMode: google.maps.TravelMode.DRIVING
  }, function(response, status) {
    if (status === google.maps.DirectionsStatus.OK) {
      directionsDisplay.setDirections(response);
    } else {
      window.alert('Directions request failed due to ' + status);
    }
  });
}
//# sourceMappingURL=main.js.map
